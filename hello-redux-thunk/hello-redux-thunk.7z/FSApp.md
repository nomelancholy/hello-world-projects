# FSApp 이해

## Next JS

### 특징

- react 기반 프레임 워크
- Server Side Rendering, SEO 등에 강점이 있다

### react와 다른 주요 개념

- 폴더 구조로 간단하게 라우팅을 처리할 수 있다.
- [id]를 활용해 간단하게 동적 라우팅을 처리할 수 있다.
- 모든 페이지를 사전에 렌더링 한다. 종류는 정적 생성과 ServerSideRendering en rkwlek

  - 정적 생성 : getStaticProps()

  - serverside : getE
